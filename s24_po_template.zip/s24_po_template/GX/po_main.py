import pandas as pd
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

import warnings
warnings.filterwarnings("ignore")

# Specify the file path
data = pd.read_csv("data.csv")
# Calculate profit for each item
data['profit'] = data['sales'] * (data['price'] - data['cost'])

# Plot profit vs. price
plt.figure(figsize=(10, 6))
plt.scatter(data['price'], data['profit'], alpha=0.5)
plt.title('Profit vs. Price')
plt.xlabel('Price')
plt.ylabel('Profit')
plt.grid(True)
plt.show()

# Drop rows with missing sales values
data.dropna(subset=['sales'], inplace=True)

# Extract features (price) and target variable (sales)
X = data[['price']]
y = data['sales']

# Initialize and fit the linear regression model
model = LinearRegression()
model.fit(X, y)

# Generate price points for prediction
price_points = np.linspace(X.min(), X.max(), 100).reshape(-1, 1)

# Predict sales for the price points
predicted_sales = model.predict(price_points)

# Plot predicted sales vs price
# Plot predicted sales vs price
plt.figure(figsize=(10, 6))
plt.scatter(X, y, alpha=0.5, label='Actual Sales')
plt.plot(price_points, predicted_sales, color='red', label='Predicted Sales')
plt.title('Predicted Sales vs. Price')
plt.xlabel('Price ($)')
plt.ylabel('Sales ($)')
plt.legend()
plt.grid(True)
plt.show()

# Function to preprocess the data and extract features
def preprocess_data(data):
    # Here, you can preprocess the data, select relevant features,
    # handle missing values, and encode categorical variables
    # For simplicity, let's select 'cost' as a feature
    X = data[['cost']]  # Selecting 'cost' as the feature
    y = data['price']   # Selecting 'price' as the target variable
    return X, y

def RecommendPrice(itemId, data1=None, time=None, date=None):

    # Filter data based on sku_id if necessary
    filtered_data = data[data['sku_id'] == int(itemId)]
    
    # Preprocess the filtered data
    X, y = preprocess_data(filtered_data)
    
    # Split data into train and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Train OLS model
    ols_model = LinearRegression()
    ols_model.fit(X_train, y_train)
    
    # Make predictions
    y_pred = ols_model.predict(X_test)
    
    # Evaluate model performance
    rmse = mean_squared_error(y_test, y_pred, squared=False)
    
    # # Print and return results
    # print("Root Mean Squared Error (RMSE) using OLS technique:", rmse)
    
    # Return recommended price (example: using first test data point)
    recommended_price = ols_model.predict([X_test.iloc[0]])[0]
    return round(recommended_price, 3)
